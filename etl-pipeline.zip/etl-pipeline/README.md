# Pipeline ETL de Ingesta y Limpieza (Pandas → Parquet)

Pipeline de datos modular que **extrae** un dataset público en CSV, lo **transforma** (normalización de columnas, eliminación de duplicados y tratamiento de nulos) y lo **carga** en un archivo **Parquet** listo para Machine Learning.

Dataset utilizado: **Titanic** (el mismo de la competencia de Kaggle), obtenido de un espejo público en GitHub. El pipeline lo descarga solo la primera vez que se ejecuta, así que **el dataset no se sube al repositorio** (ver `.gitignore`).

---

## Estructura del proyecto

```
etl-pipeline/
├── main.py              # Punto de entrada: orquesta las etapas E → T → L
├── requirements.txt     # Dependencias
├── .gitignore           # Excluye datos crudos/procesados y entornos virtuales
├── README.md
├── data/
│   ├── raw/             # CSV original (se descarga, no se versiona)
│   └── processed/       # Parquet de salida (se genera, no se versiona)
└── src/
    ├── __init__.py
    ├── config.py        # Rutas, URL del dataset, esquema de tipos
    ├── extract.py       # Descarga y lectura tipada del CSV
    ├── transform.py     # Limpieza: columnas, duplicados, nulos
    └── load.py          # Exportación a Parquet
```

`main.py` solo coordina; toda la lógica está en los módulos de `src/`, cada uno con una única responsabilidad.

---

## Instalación

Requisitos: **Python 3.10 o superior** y `git`.

```bash
# 1. Clonar el repositorio
git clone https://github.com/<tu-usuario>/etl-pipeline.git
cd etl-pipeline

# 2. Crear y activar un entorno virtual
python -m venv .venv
# Linux / macOS
source .venv/bin/activate
# Windows (PowerShell)
.venv\Scripts\Activate.ps1

# 3. Instalar dependencias
pip install -r requirements.txt
```

## Ejecución

```bash
python main.py
```

El resultado queda en `data/processed/titanic_clean.parquet`.

Opcionalmente, se pueden indicar otras rutas de entrada/salida:

```bash
python main.py --input data/raw/mi_archivo.csv --output data/processed/salida.parquet
```

> Si usás otro CSV, ajustá el esquema `DTYPES` en `src/config.py` y las reglas de nulos en `src/transform.py`.

Para verificar la salida:

```python
import pandas as pd
df = pd.read_parquet("data/processed/titanic_clean.parquet")
print(df.dtypes, df.shape, df.isna().sum().sum())
```

### Salida esperada (log)

```
INFO | src.extract   | Memoria: 0.116 MB sin tipos -> 0.066 MB con tipos (43.6% de ahorro)
INFO | src.extract   | Extraídas 891 filas y 12 columnas.
INFO | src.transform | Columnas normalizadas: ['passenger_id', 'survived', 'pclass', ...]
INFO | src.transform | Duplicados eliminados: 0
INFO | src.transform | Nulos antes: age 177, cabin 687, embarked 2
INFO | src.transform | Nulos restantes después de la limpieza: 0
INFO | src.load      | Parquet generado en data/processed/titanic_clean.parquet (40.0 KB, 891 filas)
```

---

## Etapas del pipeline

### 1. Extracción (`src/extract.py`)

- `download_dataset()` descarga el CSV **solo si no existe** localmente.
- `extract_data()` lee el CSV con un **esquema de tipos explícito** (`DTYPES` en `config.py`) en lugar de dejar que pandas los infiera:

| Tipo inferido por pandas | Tipo usado | Motivo |
|---|---|---|
| `int64` | `int8` / `int32` | Valores chicos (clase, flags, conteos) |
| `float64` | `float32` | Precisión suficiente para edad y tarifa |
| `object` | `category` | `sex` y `embarked` tienen 2–3 valores distintos |
| `object` | `string` | Texto libre (nombre, ticket) con tipo dedicado |

Resultado: **~44% menos memoria**. Con datasets más grandes el ahorro es igual de proporcional, y es lo que permite procesar volúmenes crecientes sin quedarse sin RAM.

### 2. Transformación (`src/transform.py`)

Cada paso es una función independiente, y `transform_data()` las ejecuta en orden:

1. **`normalize_column_names()`**: convierte las columnas a `snake_case` (`PassengerId` → `passenger_id`, `SibSp` → `sib_sp`) para tener nombres consistentes y sin espacios ni mayúsculas.
2. **`remove_duplicates()`**: se aplica dos veces:
   - duplicados **exactos** (filas idénticas);
   - duplicados **de negocio**: mismos datos con distinto `passenger_id` (la misma persona cargada dos veces).
   Se hace *antes* de imputar para que las filas repetidas no sesguen medianas y modas.
3. **`handle_missing_values()`**: una estrategia justificada para cada columna:

| Columna | % nulos | Estrategia | Justificación |
|---|---|---|---|
| `cabin` | ~77% | Se reemplaza por `has_cabin` (0/1) | Imputar con tantos faltantes sería inventar datos; tener o no cabina registrada sí aporta información (está asociado a 1ª clase) |
| `age` | ~20% | Mediana por `pclass` + `sex`, más el flag `age_was_missing` | La mediana es robusta a outliers; agrupar respeta que la edad varía por clase y sexo; el flag le permite al modelo distinguir los valores imputados |
| `embarked` | 2 filas | Moda | Variable categórica con muy pocos faltantes; el impacto es mínimo |
| `fare` | 0 (preventivo) | Mediana por clase | La tarifa depende fuertemente de la clase |
| `survived` | — | Se elimina la fila | Es la variable objetivo: no se debe imputar |

### 3. Carga (`src/load.py`)

`load_to_parquet()` exporta a **Parquet** con motor `pyarrow` y compresión `snappy`.

**¿Por qué Parquet es más eficiente para Machine Learning?**

- **Almacenamiento columnar**: los modelos suelen usar un subconjunto de columnas; Parquet permite leer solo esas (`pd.read_parquet(path, columns=[...])`), mientras que con CSV hay que recorrer el archivo entero.
- **Compresión**: en este caso, 60 KB (CSV) → 40 KB (Parquet), y la diferencia crece con más filas porque los datos columnares se comprimen mejor.
- **Conserva el esquema**: los tipos (`int8`, `float32`, `category`) se guardan en el archivo. Al volver a leerlo no hay que inferir ni optimizar tipos otra vez, y se evitan errores como IDs leídos como float o fechas leídas como texto.
- **Lectura más rápida**: es binario y no requiere parsear texto.
- **Ecosistema**: pandas, Dask, Spark, Polars, DuckDB y BigQuery lo leen de forma nativa, y en paralelo cuando hay varios archivos o particiones.

---

## Escalabilidad

Para datasets que no entran en memoria, el diseño modular permite cambiar `extract_data()` por `dask.dataframe.read_csv(path, dtype=DTYPES)` sin tocar el resto, ya que la API de Dask es compatible con la de pandas para estas operaciones.

## Tecnologías

- Python 3.10+
- pandas
- pyarrow
