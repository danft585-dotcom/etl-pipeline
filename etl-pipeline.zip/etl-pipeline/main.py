"""Punto de entrada del pipeline ETL.

Uso:
    python main.py
    python main.py --input data/raw/otro.csv --output data/processed/salida.parquet
"""

import argparse
import logging
import sys
import time
from pathlib import Path

from src import config
from src.extract import download_dataset, extract_data
from src.load import load_to_parquet
from src.transform import transform_data


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Pipeline ETL: CSV -> limpieza -> Parquet")
    parser.add_argument("--input", type=Path, default=config.RAW_FILE, help="CSV de entrada")
    parser.add_argument("--output", type=Path, default=config.OUTPUT_FILE, help="Parquet de salida")
    return parser.parse_args()


def run_pipeline(input_path: Path, output_path: Path) -> None:
    start = time.perf_counter()

    # 1. Extracción
    if input_path == config.RAW_FILE:
        download_dataset(config.DATASET_URL, input_path)
    df = extract_data(input_path, dtypes=config.DTYPES)

    # 2. Transformación
    df = transform_data(df)

    # 3. Carga
    load_to_parquet(df, output_path, compression=config.PARQUET_COMPRESSION)

    logging.info("Pipeline completado en %.2f s", time.perf_counter() - start)


def main() -> int:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)-7s | %(name)s | %(message)s",
    )
    args = parse_args()
    try:
        run_pipeline(args.input, args.output)
    except Exception:
        logging.exception("El pipeline falló")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
