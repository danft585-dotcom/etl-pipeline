"""Módulos del pipeline ETL: extract, transform y load."""
