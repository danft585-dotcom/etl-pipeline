"""Configuración central del pipeline: rutas, URL del dataset y esquema de tipos."""

from pathlib import Path

# --- Rutas ---------------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent.parent
RAW_DIR = BASE_DIR / "data" / "raw"
PROCESSED_DIR = BASE_DIR / "data" / "processed"

RAW_FILE = RAW_DIR / "titanic.csv"
OUTPUT_FILE = PROCESSED_DIR / "titanic_clean.parquet"

# --- Fuente de datos -----------------------------------------------------
# Dataset público Titanic (mismo que el de la competencia de Kaggle).
DATASET_URL = (
    "https://raw.githubusercontent.com/datasciencedojo/datasets/master/titanic.csv"
)

# --- Esquema de tipos para optimizar memoria -----------------------------
# Por defecto pandas usa int64/float64/object. Declarar tipos más chicos
# reduce mucho el uso de RAM:
#   - int8/int16/float32 en lugar de int64/float64
#   - "category" para columnas de texto con pocos valores distintos
#   - "Int8" (con mayúscula) es entero *nullable*, admite NaN sin pasar a float
DTYPES = {
    "PassengerId": "int32",
    "Survived": "int8",
    "Pclass": "int8",
    "Name": "string",
    "Sex": "category",
    "Age": "float32",
    "SibSp": "int8",
    "Parch": "int8",
    "Ticket": "string",
    "Fare": "float32",
    "Cabin": "string",
    "Embarked": "category",
}

# Compresión del archivo Parquet de salida
PARQUET_COMPRESSION = "snappy"
