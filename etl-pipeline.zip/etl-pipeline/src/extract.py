"""Etapa de EXTRACCIÓN: descarga (si hace falta) y lectura tipada del CSV."""

import logging
import urllib.request
from pathlib import Path

import pandas as pd

logger = logging.getLogger(__name__)


def download_dataset(url: str, destination: Path) -> Path:
    """Descarga el dataset solo si no existe localmente (evita re-descargas)."""
    if destination.exists():
        logger.info("Dataset ya presente en %s, se omite la descarga.", destination)
        return destination

    destination.parent.mkdir(parents=True, exist_ok=True)
    logger.info("Descargando dataset desde %s ...", url)
    urllib.request.urlretrieve(url, destination)
    logger.info("Dataset guardado en %s", destination)
    return destination


def memory_usage_mb(df: pd.DataFrame) -> float:
    """Uso de memoria real del DataFrame en MB (incluye strings)."""
    return df.memory_usage(deep=True).sum() / 1024**2


def extract_data(path: Path, dtypes: dict | None = None) -> pd.DataFrame:
    """Lee el CSV aplicando un esquema de tipos explícito.

    Args:
        path: ruta al archivo CSV.
        dtypes: diccionario {columna: tipo}. Si es None, pandas infiere los tipos.

    Returns:
        DataFrame con los tipos optimizados.
    """
    if not path.exists():
        raise FileNotFoundError(f"No se encontró el archivo de entrada: {path}")

    df = pd.read_csv(path, dtype=dtypes)

    # Comparación con la lectura "ingenua" para justificar la optimización
    if dtypes:
        naive_mb = memory_usage_mb(pd.read_csv(path))
        optimized_mb = memory_usage_mb(df)
        logger.info(
            "Memoria: %.3f MB sin tipos -> %.3f MB con tipos (%.1f%% de ahorro)",
            naive_mb,
            optimized_mb,
            100 * (1 - optimized_mb / naive_mb),
        )

    logger.info("Extraídas %d filas y %d columnas.", *df.shape)
    return df
