"""Etapa de CARGA: exporta el resultado a Parquet.

¿Por qué Parquet para Machine Learning?
- Columnar: se leen solo las columnas que necesita el modelo (`columns=[...]`),
  sin recorrer todo el archivo como pasa con CSV.
- Comprimido (snappy): archivos mucho más chicos que el CSV equivalente.
- Conserva el esquema: tipos (int8, float32, category) se guardan con el
  archivo, así no hay que volver a inferirlos ni re-optimizar memoria al leer.
- Rápido y compatible con el ecosistema: pandas, Dask, Spark, Polars, DuckDB,
  BigQuery, etc. leen Parquet de forma nativa y en paralelo.
"""

import logging
from pathlib import Path

import pandas as pd

logger = logging.getLogger(__name__)


def load_to_parquet(df: pd.DataFrame, path: Path, compression: str = "snappy") -> Path:
    """Guarda el DataFrame en formato Parquet (motor pyarrow)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(path, engine="pyarrow", compression=compression, index=False)
    logger.info(
        "Parquet generado en %s (%.1f KB, %d filas)",
        path,
        path.stat().st_size / 1024,
        len(df),
    )
    return path
