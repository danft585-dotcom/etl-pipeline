"""Etapa de TRANSFORMACIÓN: normalización de columnas, duplicados y nulos.

Cada paso es una función independiente y pura (recibe un DataFrame y devuelve
uno nuevo), lo que facilita testearlas por separado y reordenarlas.
"""

import logging
import re

import pandas as pd

logger = logging.getLogger(__name__)


def normalize_column_names(df: pd.DataFrame) -> pd.DataFrame:
    """Convierte los nombres de columnas a snake_case.

    Ej.: 'PassengerId' -> 'passenger_id', 'SibSp' -> 'sib_sp', 'Ticket Nro' -> 'ticket_nro'
    """

    def to_snake(name: str) -> str:
        name = name.strip()
        name = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", name)  # camelCase -> camel_Case
        name = re.sub(r"[^0-9a-zA-Z]+", "_", name)            # espacios/símbolos -> _
        return name.strip("_").lower()

    df = df.rename(columns=to_snake)
    logger.info("Columnas normalizadas: %s", list(df.columns))
    return df


def remove_duplicates(df: pd.DataFrame, subset: list[str] | None = None) -> pd.DataFrame:
    """Elimina filas duplicadas, conservando la primera aparición.

    Se usa `subset` para que el criterio de duplicado sea de negocio
    (ej.: misma persona registrada dos veces con distinto ID).
    """
    before = len(df)
    df = df.drop_duplicates(subset=subset, keep="first").reset_index(drop=True)
    logger.info("Duplicados eliminados: %d", before - len(df))
    return df


def handle_missing_values(df: pd.DataFrame) -> pd.DataFrame:
    """Gestiona los valores nulos con una estrategia justificada por columna.

    - cabin (~77% nulos): demasiados faltantes para imputar sin inventar datos.
      Se reemplaza por la variable binaria `has_cabin`, que sí aporta señal
      (los pasajeros con cabina registrada eran mayormente de 1ª clase).
    - age (~20% nulos): se imputa con la MEDIANA por (pclass, sex). La mediana
      es robusta a outliers y agrupar respeta que la edad varía por clase/sexo.
      Se agrega `age_was_missing` para que el modelo sepa qué valores se imputaron.
    - embarked (2 nulos): categórica con muy pocos faltantes -> se imputa con la MODA.
    - fare: se imputa con la mediana por clase si hubiera faltantes.
    - Filas sin la variable objetivo (`survived`) se descartan: no sirven para entrenar.
    """
    df = df.copy()
    nulls_before = df.isna().sum()
    logger.info("Nulos antes:\n%s", nulls_before[nulls_before > 0].to_string())

    # Variable objetivo: no se imputa, se descarta la fila
    if "survived" in df.columns:
        df = df.dropna(subset=["survived"])

    # Cabin -> indicador binario
    if "cabin" in df.columns:
        df["has_cabin"] = df["cabin"].notna().astype("int8")
        df = df.drop(columns=["cabin"])

    # Age -> mediana por grupo + flag
    if "age" in df.columns:
        df["age_was_missing"] = df["age"].isna().astype("int8")
        group_median = df.groupby(["pclass", "sex"], observed=True)["age"].transform("median")
        df["age"] = df["age"].fillna(group_median).fillna(df["age"].median())

    # Embarked -> moda
    if "embarked" in df.columns and df["embarked"].isna().any():
        df["embarked"] = df["embarked"].fillna(df["embarked"].mode()[0])

    # Fare -> mediana por clase
    if "fare" in df.columns and df["fare"].isna().any():
        df["fare"] = df["fare"].fillna(
            df.groupby("pclass")["fare"].transform("median")
        )

    remaining = int(df.isna().sum().sum())
    logger.info("Nulos restantes después de la limpieza: %d", remaining)
    return df.reset_index(drop=True)


def transform_data(df: pd.DataFrame) -> pd.DataFrame:
    """Orquesta todas las transformaciones en el orden correcto.

    1. Normalizar nombres (los pasos siguientes usan snake_case).
    2. Quitar duplicados exactos y luego duplicados de negocio (sin ID).
    3. Tratar nulos (después de deduplicar, para no sesgar medianas/modas).
    """
    df = normalize_column_names(df)
    df = remove_duplicates(df)  # duplicados exactos
    business_cols = [c for c in df.columns if c != "passenger_id"]
    df = remove_duplicates(df, subset=business_cols)  # misma persona, distinto ID
    df = handle_missing_values(df)
    return df
